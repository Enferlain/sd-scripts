Production implementation is **not ready**. Sections 1–3 are design milestones authorized by the current request. They precede production migration tasks, which will be added after the exchanges are concrete. OpenSpec's artifact-completeness status does not override this gate. Beads `sd-scripts-syv` tracks overall work.

## 1. Carry forward decisions and define Trainer consumption

- [ ] 1.1 Transfer the full settled direction and exchange baseline into focused requirements and scenarios; verify a source-section-to-requirement table covers Q1–Q5, topology corrections, preparation, identity/resume, artifact products and optimization identity without promoting superseded history or working names.
- [ ] 1.2 Expand design D3 into inputs, results, readiness, effects and failure behavior for each Trainer/pipeline responsibility; verify each row has an explicit owner and maps to a contract requirement without universal family slots.
- [ ] 1.3 Reconcile existing loaded-component, target-reference, grouping, adapter, metadata and observation specs and the active metadata change; verify every conflict has an explicit delta or documented unchanged requirement and an agreed migration dependency.
- [ ] 1.4 Review this design milestone with the user and review-mcp after artifact validation; verify actionable findings are addressed and the next code-inspection scope is recorded in Beads.

## 2. Derive execution and optimization from concrete cases

- [ ] 2.1 Trace SDXL fine-tune and adapter setup, training and validation against the Trainer table; verify exact source evidence identifies each retained mechanic, domain operation, state dependency and displaced owner.
- [ ] 2.2 Compare SD and SD3, including deferred loading and different conditioning/objective paths; verify the resulting scenarios do not require SDXL-specific execution anatomy.
- [ ] 2.3 Work through compound participants, a custom structured operation and an imperative research region controlling backward or advancement; verify explicit accepted authority, retained Trainer actions, state effects and rejection cases in specs.
- [ ] 2.4 Define the minimum execution representation and supported standard advancement policies from those cases; verify readable authoring/execution examples and a rationale covering complexity, hot-loop work and extension strength in design.md.
- [ ] 2.5 Complete optimization realization and step exchanges; verify inputs, results, readiness, effects, invalidation and failures, including backend-constrained construction and binding/trainability changes, are specified without a universal single-loss callback.
- [ ] 2.6 Validate artifacts and obtain review-mcp review of the completed exchange milestone; verify findings and the user's architecture discussion are reflected before choosing production types.

## 3. Complete production design and migration gate

- [ ] 3.1 Derive concrete binding/preparation types, accepted arrangement and authoring APIs from the completed consumers; verify they preserve the settled semantics and fit recurring repository boundaries with readable examples.
- [ ] 3.2 Complete caching, validation, sampling, semantic artifact persistence and runtime-resume exchanges; verify each selected capability has readiness, state ownership, results and failure scenarios distinct from core computation.
- [ ] 3.3 Add reviewed vertical production milestones beginning with the SDXL case and covering the remaining supported paths; verify every milestone traces requirement → exchange → scenario → changed code → acceptance test and names displaced authority removed in the same slice.
- [ ] 3.4 Define focused regression, conformance, failure-injection and representative performance checks; verify they exercise production behavior rather than merely repeat the isolated spike.
- [ ] 3.5 Validate the completed artifacts, obtain review-mcp review and discuss the concrete implementation plan with the user; verify all design-gate conditions in design.md are satisfied before marking production implementation ready.
